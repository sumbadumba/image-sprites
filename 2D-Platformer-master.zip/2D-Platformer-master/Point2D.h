#pragma once

struct Point2D
{
	double x;
	double y;
};