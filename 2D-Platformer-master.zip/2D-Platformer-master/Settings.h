#pragma once

#define RESOLUTION_X 800
#define RESOLUTION_Y 600

#define V_SYNC true

#define D2D_BACKGROUND_COLOR (D2D1::ColorF(0.00f, 0.60f, 0.86f, 1.0f))