# Mario-style 2D Platformer game from scratch using C++ and Direct2D

Part 1: https://youtu.be/0QNucPG6TRA

Part 2: https://youtu.be/YHkv_7VGBrI


I'm describing how I've built a 2D platformer game similar to Mario using Visual C++ and Direct2D.

If you want to keep learning and need help, join our FREE Discord server! https://discord.gg/Rt6uTeC

Facebook: https://www.facebook.com/GameBuildSucceeded/

Twitter: @SucceededBuild

Patreon: https://www.patreon.com/BuildSucceeded
