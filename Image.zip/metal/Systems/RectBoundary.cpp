#pragma once
#include "../framework.h"
#include "RectBoundary.h"

RectBoundary::RectBoundary()
{
}

RectBoundary::~RectBoundary()
{
}

void RectBoundary::SetBondary(D2D_RECT_F rect)
{
	infimum.x = rect.left;
	infimum.y = rect.top;
	supremum.x = rect.right;
	supremum.y = rect.bottom;
}

void RectBoundary::SetBondary(D2D_POINT_2F inf, D2D_POINT_2F sup)
{
	infimum = inf;
	supremum = sup;
}

void RectBoundary::SetBondary(FLOAT left, FLOAT top, FLOAT right, FLOAT bottom)
{
	infimum.x = left;
	infimum.y = top;
	supremum.x = right;
	supremum.y = bottom;
}

bool RectBoundary::CheckIntersect(RectBoundary * boundary, D2D_POINT_2F position)
{
	if (position.x >= boundary->infimum.x
		&& position.x <= boundary->supremum.x
		&& position.y >= boundary->infimum.y
		&& position.y <= boundary->supremum.y)
		return true; //AABB Aligned-Axis bounding box
	else
		return false;
}

bool RectBoundary::CheckIntersect(RectBoundary * boundary1, RectBoundary * boundary2)
{
	if (CheckIntersect(boundary1, boundary2->infimum))
		return true;

	if (CheckIntersect(boundary1, boundary2->supremum))
		return true;

	if (CheckIntersect(boundary2, boundary1->infimum))
		return true;

	if (CheckIntersect(boundary2, boundary1->supremum))
		return true;
	
	D2D_POINT_2F rightTop;
	rightTop.x = boundary2->supremum.x;
	rightTop.y = boundary2->infimum.y;
	if (CheckIntersect(boundary1, rightTop))
		return true;
	//
	D2D_POINT_2F leftBottom;
	leftBottom.x = boundary2->infimum.x;
	leftBottom.y = boundary2->supremum.y;
	if (CheckIntersect(boundary1, leftBottom))
		return true;

	return false;
}

INTERSECT_TYPE RectBoundary::CheckIntersect(RectBoundary * other)
{
	if (CheckIntersect(this, other->infimum))
		return LEFTTOP;

	if (CheckIntersect(this, other->supremum))
		return RIGHTBOTTOM;

	if (CheckIntersect(other, this->infimum))
		return INSIDE;

	if (CheckIntersect(other, this->supremum))
		return INSIDE;

	//
	D2D_POINT_2F rightTop;
	rightTop.x = other->supremum.x;
	rightTop.y = other->infimum.y;
	if (CheckIntersect(this, rightTop))
		return RIGHTTOP;
	//
	D2D_POINT_2F leftBottom;
	leftBottom.x = other->infimum.x;
	leftBottom.y = other->supremum.y;
	if (CheckIntersect(this, leftBottom))
		return LEFTBOTTOM;

	return NONE;
}
