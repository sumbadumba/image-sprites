﻿#include "../framework.h"
#include "D2D.h"

D2D* D2D::instance = NULL;

D2DDesc D2D::d2dDesc;
ID2D1Factory * D2D::D2DFactory = NULL;
IWICImagingFactory * D2D::WICFactory = NULL;
IDWriteFactory * D2D::DWriteFactory = NULL;
ID2D1HwndRenderTarget * D2D::RenderTarget = NULL;

D2D_VECTOR_2F D2D::RenderTargetRate;

D2D * D2D::Get()
{
	return instance;
}

void D2D::Create()
{
	assert(instance == NULL);

	instance = new D2D();
}

void D2D::Delete()
{
	SAFE_DELETE(instance);
}

void D2D::ResizeScreen(UINT width, UINT height)
{
	CalculateTargetRate();
}

void D2D::BeginDraw()
{
	RenderTarget->BeginDraw();
}

void D2D::SetTransform(const D2D1_MATRIX_3X2_F &transform)
{
	RenderTarget->SetTransform(transform);
}

void D2D::Clear(const D2D1_COLOR_F &clearColor)
{
	RenderTarget->Clear(clearColor);
}

HRESULT D2D::EndDraw()
{
	return RenderTarget->EndDraw();
}

HRESULT D2D::Flush()
{
	return RenderTarget->Flush();
}

D2D::D2D()
{
	CreateDeviceIndependentResources();
	CreateDeviceResources();
}

D2D::~D2D()
{
	SAFE_RELEASE(RenderTarget);
	SAFE_RELEASE(DWriteFactory);
	SAFE_RELEASE(WICFactory);
	SAFE_RELEASE(D2DFactory);
}

HRESULT D2D::CreateDeviceIndependentResources()
{
	HRESULT hr = S_OK;

	// Create a Direct2D factory.
	hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &D2DFactory);
	Assert(SUCCEEDED(hr));

	// Create WIC factory.
	hr = CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		reinterpret_cast<void **>(&WICFactory)
	);
	Assert(SUCCEEDED(hr));

	// Create a DirectWrite factory.
	hr = DWriteCreateFactory(
		DWRITE_FACTORY_TYPE_SHARED,
		__uuidof(DWriteFactory),
		reinterpret_cast<IUnknown **>(&DWriteFactory)
	);
	Assert(SUCCEEDED(hr));

	return hr;
}

HRESULT D2D::CreateDeviceResources()
{
	HRESULT hr = S_OK;

	D2D1_SIZE_U size = D2D1::SizeU(d2dDesc.Width , d2dDesc.Height);

	// Create a Direct2D render target.
	hr = D2DFactory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(d2dDesc.Handle, size),
		&RenderTarget
	);
	Assert(SUCCEEDED(hr));
	

	return hr;
}

void D2D::CalculateTargetRate()
{
	// RenderTarget 의 내부 크기는 다를 수 있다. RenderTarget의 크기와의 비율을 계산
	{
		RECT r;
		// 현재 윈도우에서 사용하는 좌표계와 RenderTarget 이 사용하는 좌표계를 보정하기 위해서
	   // 현재 윈도우의 크기를 얻는다.​
		GetClientRect(d2dDesc.Handle, &r);
		// 좌표 보정을 위해서 RenderTarget의 크기를 얻는다.
		D2D1_SIZE_F real_size = RenderTarget->GetSize();

		// 두 좌표계의 비율을 계산한다.
		RenderTargetRate.x = real_size.width / (r.right - r.left);
		RenderTargetRate.y = real_size.height / (r.bottom - r.top);
	}

}