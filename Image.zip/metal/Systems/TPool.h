#pragma once

#include "../framework.h"

template<class T>
class TPool
{
public:
	TPool() {}
	~TPool()
	{
		Delete();
	}

private:
	queue<T * > repository;

public:
	void Generate(int count)
	{
		while (count-- > 0)
			repository.push(new T());
	}

	void Delete()
	{
		T * ptr = nullptr;
		while (!repository.empty())
		{
			ptr = repository.front();
			repository.pop();
			SAFE_DELETE(ptr);
		}
	}

	T * Acquire()
	{
		if (repository.empty())
			return nullptr;

		T * value = repository.front();
		repository.pop();
		return value;
	}

	void Release(T * value)
	{
		repository.push(value);
	}

};