#include "../framework.h"
#include "SpriteReader.h"
#include "../Object/GameObject.h"
#include "../Object/UVAnimation.h"

SpriteReader::SpriteReader(GameObject * object)
	: object(object)
{
}

SpriteReader::~SpriteReader()
{

}

bool SpriteReader::Load(wstring filePath)
{

	Xml::XMLDocument * document = new Xml::XMLDocument();
	Xml::XMLError error = document->LoadFile(String::ToString(filePath).c_str());

	if (error != Xml::XML_SUCCESS)
	{
		wstring message = L"SpriteReader::Load error! file = " + filePath + L"\n";
		OutputDebugString(message.c_str());
		assert(0);
		return false;
	}
	
	assert(error == Xml::XML_SUCCESS);

	Xml::XMLElement* root = document->FirstChildElement();
	Xml::XMLElement* node = NULL;

	node = root->FirstChildElement();
	ReadLoopImageFilePath(node);

	node = node->NextSiblingElement();
	D2D1_SIZE_U divide = ReadLoopDivide(node);

	node = node->NextSiblingElement();
	bool loopAnim = ReadLoopAnim(node);
	float updateInterval = ReadUpdateInterval(node);

	D2D1_SIZE_F offset;
	offset.width = image->ImageSize().width / divide.width;
	offset.height = image->ImageSize().width / divide.height;
	object->AnimationObject()->SetUVAnimation(divide.width, divide.height, offset, updateInterval);
	object->AnimationObject()->LoopAnim(loopAnim);

	node = node->NextSiblingElement();
	ReadBoundoffset(node);

	return true;
}

void SpriteReader::ReadLoopImageFilePath(Xml::XMLElement * node)
{
	wstring imageFile = String::ToWString(node->GetText());
	object->Load(imageFile);
	image = object->AnimationObject()->Image();
}

D2D1_SIZE_U SpriteReader::ReadLoopDivide(Xml::XMLElement * node)
{
	D2D1_SIZE_U divide;

	string attr;
	attr = node->Attribute("Width");
	divide.width = static_cast<UINT>(stoi(attr));

	attr = node->Attribute("Height");
	divide.height = static_cast<UINT>(stoi(attr));

	return divide;
}

bool SpriteReader::ReadLoopAnim(Xml::XMLElement * node)
{
	string attr;
	attr = node->Attribute("Value");
	if (attr.compare("True") == 0
		|| attr.compare("true") == 0
		|| attr.compare("TRUE") == 0)
	{
		return true;
	}

	return false;
}

float SpriteReader::ReadUpdateInterval(Xml::XMLElement * node)
{
	string attr;
	attr = node->Attribute("UpdateInterval");
	return stof(attr);
}


void SpriteReader::ReadBoundoffset(Xml::XMLElement * node)
{
	D2D1_RECT_F boundOffset;
	string attr;
	
	attr = node->Attribute("Left");
	boundOffset.left = stof(attr);

	attr = node->Attribute("Top");
	boundOffset.top = stof(attr);

	attr = node->Attribute("Right");
	boundOffset.right = stof(attr);

	attr = node->Attribute("Bottom");
	boundOffset.bottom = stof(attr);

	object->BoundOffset(boundOffset);
}