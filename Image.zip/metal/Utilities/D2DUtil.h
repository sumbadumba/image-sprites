#pragma once

class D2DUtil
{
public:
	static D2D1_VECTOR_2F & NomalizeVector2F(D2D1_VECTOR_2F & vec);

	static D2D1_POINT_2F & NomalizePoint2F(D2D1_POINT_2F & point);
	static D2D1_POINT_2U & NomalizePoint2U(D2D1_POINT_2U & point);

	static D2D1_RECT_F & NomalizeRectF(D2D1_RECT_F & rect);
	static D2D1_RECT_U & NomalizeRectU(D2D1_RECT_U & rect);

	static D2D1_SIZE_F & NomalizeSizeF(D2D1_SIZE_F & size);
	static D2D1_SIZE_U & NomalizeSizeU(D2D1_SIZE_U & size);

	//
	static void FixRect(D2D1_RECT_F& rect);

	static bool IsSameMatrix3x2F(Matrix3x2F m1, Matrix3x2F m2);	// ������ true
};

	