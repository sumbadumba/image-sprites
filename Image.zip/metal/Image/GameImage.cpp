#include "../framework.h"
#include "GameImage.h"
#include "../ImageEffect/ImageEffect.h"

GameImage::GameImage()
	: imageEffect(NULL)
{
}

GameImage::~GameImage()
{
	SAFE_DELETE(imageEffect);
}

void GameImage::Render(D2D1_RECT_F drawRect, Matrix3x2F transformMatrix)
{
	if(imageEffect == NULL)
		__super::Render(drawRect, transformMatrix);
	else
		imageEffect->Render(this, drawRect, transformMatrix);
}

