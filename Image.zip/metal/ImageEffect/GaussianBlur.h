#pragma once

#include "ImageEffect.h"

class GaussianBlur : public ImageEffect
{
public:
	GaussianBlur();
	~GaussianBlur();

	void SetStandardDeviation(float StDev);

private:
	const float DefaultStDev = 5.0f;
};

