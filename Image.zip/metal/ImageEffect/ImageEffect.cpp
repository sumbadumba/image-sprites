#include "../framework.h"
#include "ImageEffect.h"
#include "../Image/Image.h"

ImageEffect::ImageEffect(REFCLSID clsID)
	: DeviceContext(NULL), BitmapRenderTarget(NULL), Effect(NULL)
{
	targetOffset.x = 0.0f;
	targetOffset.y = 0.0f;

	HRESULT hr = S_OK;
	// Create bitmapRenderTarget
	D2D::Get()->GetRenderTarget()->CreateCompatibleRenderTarget(
		D2D1::SizeF(D2D::Get()->GetRenderTarget()->GetSize().width,
			D2D::Get()->GetRenderTarget()->GetSize().height
		),
		&BitmapRenderTarget);

	// ��Ʈ���� ����
	ID2D1Bitmap *bitmap;
	BitmapRenderTarget->GetBitmap(&bitmap);

	// ����̽� ���ؽ�Ʈ Ȯ��
	hr = D2D::Get()->GetRenderTarget()->QueryInterface(&DeviceContext);
	assert(SUCCEEDED(hr));

	// ����Ʈ ����
	hr = DeviceContext->CreateEffect(clsID, &Effect);
	assert(SUCCEEDED(hr));

	Effect->SetInput(0, bitmap);
	interplationMode = D2D1_INTERPOLATION_MODE_LINEAR;
}

ImageEffect::~ImageEffect()
{
	SAFE_RELEASE(Effect);
	SAFE_RELEASE(BitmapRenderTarget);
	SAFE_RELEASE(DeviceContext);
}

void ImageEffect::Render(Image * image, D2D1_RECT_F drawRect, Matrix3x2F transformMatrix)
{
	// Draw onto bitmapRenderTarget
	BitmapRenderTarget->BeginDraw();
	image->RenderBitmapTarget(BitmapRenderTarget, drawRect, transformMatrix);
	BitmapRenderTarget->EndDraw();

	// Draw resulting bitmap
	DeviceContext->DrawImage(Effect, targetOffset, interplationMode);
}