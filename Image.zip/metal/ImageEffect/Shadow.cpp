#include "../framework.h"
#include "Shadow.h"

Shadow::Shadow()
	: ImageEffect(CLSID_D2D1Shadow)
{
	Color.r = 0.0f;
	Color.g = 0.0f;
	Color.b = 0.0f;
	Color.a = 1.0f;

	Effect->SetValue(D2D1_SHADOW_PROP_BLUR_STANDARD_DEVIATION, DefaultBlurStandardDeviation);
	Effect->SetValue(D2D1_SHADOW_PROP_COLOR, Color);
	Effect->SetValue(D2D1_SHADOW_PROP_OPTIMIZATION, D2D1_SHADOW_OPTIMIZATION_SPEED);

	ID2D1Bitmap *bitmap;
	BitmapRenderTarget->GetBitmap(&bitmap);
	HRESULT hr = DeviceContext->CreateEffect(CLSID_D2D12DAffineTransform, &AffineTransformEffect);
	assert(SUCCEEDED(hr));

	Distance.x = 0.0f;
	Distance.y = 0.0f;

	AffineTransformEffect->SetInputEffect(0, Effect);
	D2D1_MATRIX_3X2_F translation = D2D1::Matrix3x2F::Translation(Distance.x, Distance.y);
	AffineTransformEffect->SetValue(D2D1_2DAFFINETRANSFORM_PROP_TRANSFORM_MATRIX, translation);

}

Shadow::~Shadow()
{
	SAFE_RELEASE(AffineTransformEffect);

}

void Shadow::SetBlurStandardDeviation(float StDev)
{
	Effect->SetValue(D2D1_SHADOW_PROP_BLUR_STANDARD_DEVIATION, StDev);
}

void Shadow::Translation(FLOAT x, FLOAT y)
{
	Distance.x = x;
	Distance.y = y;
	D2D1_MATRIX_3X2_F translation = D2D1::Matrix3x2F::Translation(Distance.x, Distance.y);
	AffineTransformEffect->SetValue(D2D1_2DAFFINETRANSFORM_PROP_TRANSFORM_MATRIX, translation);
}

void Shadow::Render(Image * image, D2D1_RECT_F drawRect, Matrix3x2F transformMatrix)
{
	// Draw onto bitmapRenderTarget
	BitmapRenderTarget->BeginDraw();
	image->RenderBitmapTarget(BitmapRenderTarget, drawRect, transformMatrix);
	BitmapRenderTarget->EndDraw();

	// Draw resulting bitmap
	DeviceContext->DrawImage(AffineTransformEffect, interplationMode);

}