﻿#pragma once

class TransformObject
{
public:
	TransformObject();
	TransformObject(D2D1_POINT_2F pos, FLOAT rot, D2D1_VECTOR_2F scale);
	~TransformObject();
public:
	virtual void Update();
	virtual void UpdateDrawRect();

	virtual void Render();
	//
	void Load(wstring filePath);

	class UVAnimation * AnimationObject() { return animationObject; }

	D2D1_POINT_2F Position() { return position; }
	void Position(D2D1_POINT_2F val);

	FLOAT Rotation() { return rotation; }
	void Rotate(FLOAT delta, D2D1_POINT_2F rotPoint = Point2F());

	D2D1_VECTOR_2F Scale() { return scale; }
	void Scale(D2D1_VECTOR_2F val);
	void Scaling(D2D1_VECTOR_2F delta);

	Matrix3x2F TransformMatrix() { return transformMatrix; }
	void UpdateMatrix();

	virtual void Move(D2D1_VECTOR_2F delta);

	D2D1_RECT_F DrawRect() { return drawRect; }

	bool Active() { return active; }
	void Active(bool value) { active = value; }
	bool EnableRender() { return enableRender; }
	void EnableRender(bool value) { enableRender = value; }

protected:
	D2D1_POINT_2F position; // Center 위치
	FLOAT rotation;	// 회전값
	D2D1_VECTOR_2F scale;	// 배율

private:
	class UVAnimation * animationObject;

	Matrix3x2F scaleMatrix;
	Matrix3x2F rotationMatrix;
	Matrix3x2F translationMatrix;
	Matrix3x2F transformMatrix;

	// 그려질 대상 위치의 사각형
	D2D1_RECT_F drawRect;

	bool active;
	bool enableRender;
};

