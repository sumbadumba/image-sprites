#include "../framework.h"
#include "UVAnimation.h"

UVAnimation::UVAnimation()
	: image(NULL), useUVAnim(false), loopAnim(false), uvOffset(SizeF())
{
}


UVAnimation::~UVAnimation()
{
	if (image != NULL)
	{
		ImageCache::Get()->Unload(image);
		image = NULL;
	}
}

void UVAnimation::Update()
{
	if (useUVAnim)
		UpdateUVAnimation();
}

void UVAnimation::Render(D2D1_RECT_F drawRect, Matrix3x2F transformMatrix)
{
	image->Render(drawRect, transformMatrix);
}

void UVAnimation::Load(wstring filePath)
{
	if (image != NULL)
	{
		ImageCache::Get()->Unload(image);
		image = NULL;
	}

	image = ImageCache::Get()->Load(filePath);
	image->FilePath(filePath);

	srcRect = image->SrcRect();
}

void UVAnimation::SetUVAnimation(UINT divideWidth, UINT divideHeight, D2D1_SIZE_F offset, float updateInterval, bool loop)
{
	this->divideWidth = divideWidth;
	this->divideHeight = divideHeight;
	xIndex = 0;
	yIndex = 0;
	uvOffset = offset;

	this->updateInterval = updateInterval;
	LastUpdateTime = -updateInterval;
	//
	useUVAnim = true;
}

void UVAnimation::ResetUVAnimation()
{
	xIndex = 0;
	yIndex = 0;
	LastUpdateTime = -updateInterval;
	useUVAnim = true;
}

void UVAnimation::UpdateUVAnimation()
{
	float currentTime = Time::Get()->Running();
	float deltaTime = currentTime - LastUpdateTime;
	if (deltaTime < updateInterval)
		return;

	srcRect.left = xIndex * uvOffset.width;
	srcRect.top = yIndex * uvOffset.height;
	srcRect.right = srcRect.left + uvOffset.width;
	srcRect.bottom = srcRect.top + uvOffset.height;

	image->SrcRect(srcRect);
	//
	xIndex++;
	if (xIndex >= divideWidth)
	{
		xIndex = 0;
		yIndex++;

		if (yIndex >= divideHeight)
		{
			yIndex = 0;
			if (!loopAnim)
				useUVAnim = false;
		}
	}
	//
	LastUpdateTime = currentTime;
}
