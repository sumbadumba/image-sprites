#pragma once

#include "IGeometry.h"

class EllipseGeometry : public IGeometry
{
public:
	EllipseGeometry();
	~EllipseGeometry();

	void Set(D2D1_RECT_F rect) override;

private:
	ID2D1EllipseGeometry * ellipseGeometry;

};

