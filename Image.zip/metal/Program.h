#pragma once

class Program
{
public:
	Program();
	~Program();

	void Initialize();
	void Update();
	void Render();

private:
	ExecuteValues* values;
	vector<class Exe *> Exes;

	D2D1::Matrix3x2F renderTargetTransform;
	D2D1_COLOR_F clearColor;

};