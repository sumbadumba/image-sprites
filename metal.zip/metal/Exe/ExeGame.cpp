﻿#include "../framework.h"
#include "./Exe.h"
#include "../Exe/ExeGame.h"
#include "../Image/ScrollImage.h"
#include "../Player/Player.h"

ExeGame::ExeGame(ExecuteValues* values)
	: Exe(values)
{
	InitializeBackground();
	InitializePlayer();

}

ExeGame::~ExeGame()
{
	SAFE_DELETE(player_up);
	SAFE_DELETE(player_low);
	SAFE_DELETE(image1);
	SAFE_DELETE(image2);
	SAFE_DELETE(image3);
	
}

void ExeGame::Update()
{
	UpdateInput();

	image1->Update();
	image2->Update();
	image3->Update();

	
	
	player_low->Update();
	player_up->Update();

	


}

void ExeGame::Render()
{
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D1_RECT_F drawRect = { 0, 0, renderTargetSize.width, renderTargetSize.height };

	image1->Render(drawRect);
	image2->Render(drawRect);

	player_low->Render();
	player_up->Render();

}


void ExeGame::InitializeBackground()
{
	D2D1_POINT_2F scrollSpeed = { 0.0f, 0.0f };
	//
	
	image1 = new ScrollImage(scrollSpeed);
	image1->Load(Images + L"Map_Image/Map_background.png");

	image2 = new ScrollImage(scrollSpeed);
	image2->Load(Images + L"Map_Image/Map_two.png");

	image3 = new ScrollImage(scrollSpeed);
	image3->Load(Images + L"Map_Image/Map_long.png");

}

void ExeGame::InitializePlayer()
{
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D_POINT_2F pos;

	pos.x = renderTargetSize.width / 2 * 0.2;
	pos.y = renderTargetSize.height / 2;


	player_low = new Player();
	player_low->Scale(loSize_stay_R);
	player_low->LoadSprite(Sprites + L"Eri_stay_lower_R.spr");
	player_low->Position(pos);
	

	player_up = new Player();
	player_up->Scale(upSize_stay_R);
	player_up->LoadSprite(Sprites + L"Eri_stay_upper_R.spr");
	player_up->Position(upper_plus(pos));
	SetdirectAttack(Update_UP_Action(RIGHT));//처음에 방향을 오른쪽으로 초기화

}

void ExeGame::UpdateInput()
{
	UpdateKeyboard();
}

void ExeGame::UpdateKeyboard()
{
	if (player_low != NULL)
	{
		D2D_VECTOR_2F delta;	
		
		delta.x = delta.y = 0.0f;

		if (Keyboard::Get()->Down('A'))
		{
			if (!GetdirectAttack()) // STAY_LEFT
			{
				D2D_POINT_2F lowpos = player_low->Position();
				lowpos.x -= 13.0f;
				lowpos.y -= 18.0f;

				player_up->Scale(upSize_gun_L);
				player_up->Position(lowpos);
				player_up->LoadSprite(Sprites + L"Eri_gun_upper_L.spr");
				lowpos = player_up->Position();// lowpos의 값 복원
			}
			if (GetdirectAttack()) // STAY_RIGHT
			{
				D2D_POINT_2F lowpos = player_low->Position();
				lowpos.x += 13.0f;
				lowpos.y -= 18.0f;

				player_up->Scale(upSize_gun_R);
				player_up->Position(lowpos);
				player_up->LoadSprite(Sprites + L"Eri_gun_upper_R.spr");
				lowpos = player_up->Position();// lowpos의 값 복원
				
			}

		}
		if (Keyboard::Get()->Down(VK_RIGHT))

		{
			SetdirectAttack(Update_UP_Action(RIGHT));
			player_low->Scale(loSize_run_R);
			player_low->LoadSprite(Sprites + L"Eri_run_lower_R.spr");

			D2D_POINT_2F lowpos = player_low->Position();
			lowpos.x += 5.0f;
			lowpos.y -= 12.0f;

			player_up->Scale(upSize_run_R);
			player_up->Position(lowpos);
			player_up->LoadSprite(Sprites + L"Eri_run_upper_R.spr");
			lowpos = player_up->Position();// lowpos의 값 복원

		}
		if (Keyboard::Get()->Press(VK_RIGHT))
		{

			if(Position_check)//true이면 pl
			{
				delta.x += 100.0F * Time::Delta();
				UpdateScreenCheck(delta,Go);
			}
			if (!Position_check)
			{
				delta.x = 0.000001F;
	 
			}
			
		}
		if (Keyboard::Get()->Up(VK_RIGHT))
		{
			UpdateScreenCheck(delta, Stop);
			D2D_POINT_2F lowpos = player_low->Position();
			lowpos.x += 5.0f;
			lowpos.y -= 12.0f;

			player_up->Position(lowpos);
			player_low->Scale(loSize_stay_R);
			player_up->Scale(upSize_stay_R);
			player_low->LoadSprite(Sprites + L"Eri_stay_lower_R.spr");
			player_up->LoadSprite(Sprites + L"Eri_stay_upper_R.spr");
			lowpos = player_up->Position();// lowpos의 값 복원
		}

////////////////////////////////////////////////////////////////////////////////////

		if (Keyboard::Get()->Down(VK_LEFT))
		{
			SetdirectAttack(Update_UP_Action(LEFT));
			player_low->Scale(loSize_run_L);
			player_low->LoadSprite(Sprites + L"Eri_run_lower_L.spr");
			
			D2D_POINT_2F lowpos = player_low->Position();
			lowpos.x -= 5.0f;
			lowpos.y -= 12.0f;

			player_up->Scale(upSize_run_L);
			player_up->Position(lowpos);
			player_up->LoadSprite(Sprites + L"Eri_run_upper_L.spr");

			lowpos = player_up->Position();// lowpos의 값 복원

		}
	
		if (Keyboard::Get()->Press(VK_LEFT))
		{
			delta.x -= 100.0F * Time::Delta();
			UpdateScreenCheck(delta,true);
		}

		if (Keyboard::Get()->Up(VK_LEFT))
		{
			D2D_POINT_2F lowpos = player_low->Position();
			lowpos.x -= 5.0f;
			lowpos.y -= 12.0f;

			player_up->Position(lowpos);
			player_low->Scale(loSize_stay_L);
			player_up->Scale(upSize_stay_L);
			player_low->LoadSprite(Sprites + L"Eri_stay_lower_L.spr");
			player_up->LoadSprite(Sprites + L"Eri_stay_upper_L.spr");
		}

		if (delta.x != 0.0f || delta.y != 0.0f)
		{
			player_low->Move(delta);
			player_up->Move(delta);
		}

	}
}

int ExeGame::Update_UP_Action(int direct)
{

	switch (direct)
	{
		case LEFT:
			return false;

		case RIGHT:
			return true;

	//case UP:

	//case DOWN:
	}
	return true;
}


void ExeGame::UpdateScreenCheck(D2D_VECTOR_2F delta,bool how)
{
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();

	float screen0 = 0.0f;
	float screen1 = renderTargetSize.width * 0.35f;
	float screen2 = renderTargetSize.width;



	// Scrollspeed.x + 
	if (player_low->Position().x >= screen1 && player_low->Position().x <= screen2)//  |o|x|x|x|
	{
		if (Stop == how) // stay가 false이면 화면은 정지
			scrollSpeed.x = 0.0f;

		if(Go == how)
		{
			scrollSpeed.x = -100.0f;
			image2->SetSpeed(scrollSpeed);

		}
		Position_check = false; //움직이고 있으면 

	}
	if (player_low->Position().x >= screen0 && player_low->Position().x <= screen1)
	{
		scrollSpeed.x = 0.0f;
		image2->SetSpeed(scrollSpeed);
		Position_check = true;
	}


}

D2D_POINT_2F ExeGame::upper_plus(D2D_POINT_2F pos)
{
	pos.x += 4;
	pos.y -= 15;

	return pos;
}

