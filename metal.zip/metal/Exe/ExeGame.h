#pragma once
#include "./Exe.h"

enum actionNum
{
	LEFT = 0,
	RIGHT,
	UP,
	DOWN,

};


class ExeGame : public Exe
{
public:
	ExeGame(ExecuteValues* values);
	~ExeGame();

	void Update() override;
	void Render() override;

private:
	void InitializeBackground();
	void InitializePlayer();

	void UpdateInput();
	void UpdateMouseInput();
	void UpdateKeyboard();
	 
	int Update_UP_Action(int direct);

	void SetdirectAttack(int Newdirect) { direct = Newdirect; }

	bool GetdirectAttack() { return direct; }

	void UpdateScreenCheck(D2D_VECTOR_2F delta,bool how);
	
	void Shoot(class GameObject * shooter);

private:
	D2D_POINT_2F upper_plus(D2D_POINT_2F pos);

private:
	class PlayerBullet * playerbullet;

	bool direct;
	class ScrollImage * image1;
	//class ScrollImage * image2;
	class ScrollImage * image3;

	D2D1_POINT_2F scrollSpeed;
	
	float speed;

	//stayL
	D2D_VECTOR_2F loSize_stay_L = { 1.0f,1.0f };
	D2D_VECTOR_2F upSize_stay_L = { 1.0f,1.0f };

	//stayR
	D2D_VECTOR_2F loSize_stay_R = { 1.0f,1.0f };
	D2D_VECTOR_2F upSize_stay_R = { 1.0f,1.0f };

	//run_L
	D2D_VECTOR_2F loSize_run_L = { 0.9f,0.09f };
	D2D_VECTOR_2F upSize_run_L = { 0.9f,0.09f };

	//run_R
	D2D_VECTOR_2F loSize_run_R = { 0.9f,0.1f };
	D2D_VECTOR_2F upSize_run_R = { 0.9f,0.1f };
	
	//gun_L
	D2D_VECTOR_2F upSize_gun_L= { 0.9f,0.1f };
	
	//gun_R
	D2D_VECTOR_2F upSize_gun_R = { 0.9f,0.1f };



	class Player * player_up;
	class Player * player_low;
	bool Position_check = true;

	bool Stop = false;
	bool Go = true;
};


