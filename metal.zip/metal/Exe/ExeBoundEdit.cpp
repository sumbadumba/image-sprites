﻿#include "../framework.h"
#include "./ExeBoundEdit.h"
#include "../Object/GameObject.h"
#include "../Object/UVAnimation.h"
#include "../File/SpriteWriter.h"
#include "../File/SpriteReader.h"

const UINT ExeBoundEdit::DefaultDivideWidth = 2;
const UINT ExeBoundEdit::DefaultDivideHeight = 2;
const float ExeBoundEdit::DefaultUpdateInterval = 0.1f;


ExeBoundEdit::ExeBoundEdit(ExecuteValues* values)
	: Exe(values)
{
	HRESULT hr = S_OK;
	hr = D2D::GetRenderTarget()->CreateSolidColorBrush(D2D1::ColorF(0, 0, 1), &boundaryBrush);
	Assert(SUCCEEDED(hr));

	hr = D2D::GetRenderTarget()->CreateSolidColorBrush(D2D1::ColorF(0, 1, 0), &editBoundaryBrush);
	Assert(SUCCEEDED(hr));
	///////////////////////////////////////////////////
	{
		// 클래스의 함수 포인터 전달시 않되는 예시
		//Path::OpenFileDialog(L"", L"*.png", Images, LoadImagefile);
#ifndef SPRITE_LOAD_MODE
		Path::OpenFileDialog(L"", L"*.png", Images, bind(&ExeBoundEdit::LoadImagefile, this, placeholders::_1));
#else
		Path::OpenFileDialog(L"", L"*.spr", Sprites, bind(&ExeBoundEdit::LoadSpritefile, this, placeholders::_1));
#endif

	}
}

ExeBoundEdit::~ExeBoundEdit()
{
	SAFE_RELEASE(boundaryBrush);
	SAFE_DELETE(object);
}

void ExeBoundEdit::Update()
{
	if (object == NULL)
		return;
	object->Update();

	UpdateMouseInput();
	UpdateKeyboardInput();

}

void ExeBoundEdit::Render()
{
	if (object == NULL)
		return;
	object->Render();

	D2D1_RECT_F rect;
	rect.left = object->Bound()->Infimum().x;
	rect.top = object->Bound()->Infimum().y;
	rect.right = object->Bound()->Supremum().x;
	rect.bottom = object->Bound()->Supremum().y;
	//
	D2D1_ANTIALIAS_MODE oldMode = D2D::GetRenderTarget()->GetAntialiasMode();
	D2D::GetRenderTarget()->SetAntialiasMode(D2D1_ANTIALIAS_MODE_ALIASED);
	
	D2D::GetRenderTarget()->DrawRectangle(rect, boundaryBrush);
	D2D::GetRenderTarget()->DrawRectangle(editBoundRect, editBoundaryBrush);

	D2D::GetRenderTarget()->SetAntialiasMode(oldMode);
}

void ExeBoundEdit::UpdateMouseInput()
{
	D2D_VECTOR_3F mousePos;
	if (Mouse::Get()->Down(0))
	{
		mousePos = Mouse::Get()->GetPosition();
		editBoundRect.right = editBoundRect.left = mousePos.x;
		editBoundRect.bottom = editBoundRect.top = mousePos.y;
	}
	else if (Mouse::Get()->Up(0))
	{
		mousePos = Mouse::Get()->GetPosition();
		editBoundRect.right = mousePos.x;
		editBoundRect.bottom = mousePos.y;
		NORMALIZE_RECT_F(editBoundRect);
		//
	}
	else if (Mouse::Get()->Press(0))
	{
		mousePos = Mouse::Get()->GetPosition();
		editBoundRect.right = mousePos.x;
		editBoundRect.bottom = mousePos.y;
		NORMALIZE_RECT_F(editBoundRect);
	}
}

void ExeBoundEdit::UpdateKeyboardInput()
{
	if (Keyboard::Get()->Down('A'))
	{
		D2D1_RECT_F boundOffset;
		D2D1_RECT_F drawRect = object->DrawRect();

		boundOffset.left = editBoundRect.left - drawRect.left;
		boundOffset.top = editBoundRect.top - drawRect.top;
		boundOffset.right = editBoundRect.right - drawRect.right;
		boundOffset.bottom = editBoundRect.bottom - drawRect.bottom;

		object->BoundOffset(boundOffset);

		editBoundRect.left = editBoundRect.top = editBoundRect.right = editBoundRect.bottom = 0.0f;
	}

	if (Keyboard::Get()->Down('S'))
	{
		wstring imageFilePath = object->AnimationObject()->Image()->FilePath();
		wstring spriteFilename = Path::GetFileNameWithoutExtension(imageFilePath);
		spriteFilename += L".spr";

		Path::SaveFileDialog(spriteFilename, L"*.spr", Sprites, bind(&ExeBoundEdit::SaveSpritefile, this, placeholders::_1));
	}
}

void ExeBoundEdit::LoadImagefile(wstring filePath)
{
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D_POINT_2F pos;
	pos.x = renderTargetSize.width / 2;
	pos.y = renderTargetSize.height / 2;

	D2D_VECTOR_2F scale = { 1.0f, 1.0f };
	//
	object = new GameObject(pos, 0.0f, scale);
	object->Load(filePath.c_str());

	UVAnimation * animObject = object->AnimationObject();
	GameImage * image = animObject->Image();
	D2D1_SIZE_F offset;
	offset.width = image->ImageSize().width / DefaultDivideWidth;
	offset.height = image->ImageSize().height / DefaultDivideHeight;
	animObject->SetUVAnimation(DefaultDivideWidth, DefaultDivideHeight, offset, DefaultUpdateInterval);
	animObject->LoopAnim(true);
}

void ExeBoundEdit::SaveSpritefile(wstring filePath)
{
	wstring directory = Path::GetDirectoryName(filePath);
	wstring spriteFilename = Path::GetFileName(filePath);

	SpriteWriter * writer = new SpriteWriter(object);
	writer->Write(directory, spriteFilename);
	SAFE_DELETE(writer);
}

void ExeBoundEdit::LoadSpritefile(wstring filePath)
{
	object = new GameObject();
	SpriteReader * reader = new SpriteReader(object);
	reader->Load(filePath);
	SAFE_DELETE(reader);


	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D_POINT_2F pos;
	pos.x = renderTargetSize.width / 2;
	pos.y = renderTargetSize.height / 2;
	object->Position(pos);
}
