#pragma once
#include "./Exe.h"

#define SPRITE_LOAD_MODE

class ExeBoundEdit : public Exe
{
public:
	ExeBoundEdit(ExecuteValues* values);
	~ExeBoundEdit();


	void Update() override;
	void Render() override;


	void UpdateMouseInput();
	void UpdateKeyboardInput();

	void LoadImagefile(wstring filePath);

	void SaveSpritefile(wstring filePath);
	void LoadSpritefile(wstring filePath);
private:
	class GameObject * object;

	ID2D1SolidColorBrush * boundaryBrush;

	ID2D1SolidColorBrush * editBoundaryBrush;
	D2D1_RECT_F editBoundRect;

	static const UINT DefaultDivideWidth;
	static const UINT DefaultDivideHeight;
	static const float DefaultUpdateInterval;
};


