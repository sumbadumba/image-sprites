#pragma once


struct ExecuteValues
{
	D2D_VECTOR_2F TargetRate;
};

class Exe
{
public:
	Exe(ExecuteValues* values)
		: values(values)
	{
		
	}

	virtual ~Exe(){}
	virtual void Update() = 0;
	virtual void Render() = 0;


protected:
	ExecuteValues* values;
};