#include "../framework.h"
#include "EllipseGeometry.h"

EllipseGeometry::EllipseGeometry()
	: ellipseGeometry(NULL)
{
}

EllipseGeometry::~EllipseGeometry()
{
	SAFE_RELEASE(ellipseGeometry);
}

void EllipseGeometry::Set(D2D1_RECT_F rect)
{
	float w = rect.right - rect.left;
	float h = rect.bottom - rect.top;

	if (w == width && h == height)
		return;

	width = w;
	height = h;

	SAFE_RELEASE(ellipseGeometry);

	const D2D1_ELLIPSE geometryCircle = D2D1::Ellipse(Point2F(), width * 0.5f, height * 0.5f);

	HRESULT hr = S_OK;
	hr = D2D::GetFactory()->CreateEllipseGeometry(geometryCircle, &ellipseGeometry);
	assert(SUCCEEDED(hr));

	Geometry(ellipseGeometry);
}
