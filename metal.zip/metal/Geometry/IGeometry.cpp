#include "../framework.h"
#include "IGeometry.h"

IGeometry::IGeometry()
	: geometry(NULL), debugBrush(NULL), transformedGeometry(NULL)
	, transformMatrix(Matrix3x2F::Identity())
	, width(0.0f)
	, height(0.0f)
{
	HRESULT hr = S_OK;

	hr = D2D::GetRenderTarget()->CreateSolidColorBrush(D2D1::ColorF(0, 1, 0), &debugBrush);
	assert(SUCCEEDED(hr));
}

IGeometry::~IGeometry()
{
	SAFE_RELEASE(transformedGeometry);
	SAFE_RELEASE(debugBrush);
}

void IGeometry::UpdateGeometry(D2D1_POINT_2F point, FLOAT rotation, D2D1_VECTOR_2F scale)
{
	this->point = point;
	this->rotation = rotation;
	this->scale = scale;

	Matrix3x2F scaleMatrix = Matrix3x2F::Scale(this->scale.x, this->scale.y);
	Matrix3x2F rotationMatrix = Matrix3x2F::Rotation(this->rotation, Point2F());
	Matrix3x2F translationMatrix = Matrix3x2F::Translation(this->point.x, this->point.y);

	transformMatrix.SetProduct(scaleMatrix, rotationMatrix);
	transformMatrix.SetProduct(transformMatrix, translationMatrix);
}

void IGeometry::Render()
{
#ifndef DEBUG
	return;
#else
#ifndef GEOMETRY_DEBUG
	return;
#endif // GEOMETRY_DEBUG
#endif
	if (geometry == NULL)
		return;

	Matrix3x2F oldTransform;
	D2D::GetRenderTarget()->GetTransform(&oldTransform);
	D2D::GetRenderTarget()->SetTransform(transformMatrix);
	D2D::GetRenderTarget()->DrawGeometry(geometry, debugBrush);
	D2D::GetRenderTarget()->SetTransform(oldTransform);
}

bool IGeometry::Intersect(IGeometry * other)
{
	if (other == NULL || other->Geometry() == NULL)
		return false;

	HRESULT hr = S_OK;

	D2D1_GEOMETRY_RELATION relation;

	ID2D1TransformedGeometry * transformed = TransformedGeometry();
	if (transformed == NULL)
		return false;

	hr = transformed->CompareWithGeometry(
		other->Geometry(),
		other->TransformMatrix(),
		0.1f,
		&relation
	);
	assert(SUCCEEDED(hr));

	if (relation == D2D1_GEOMETRY_RELATION_DISJOINT
		|| relation == D2D1_GEOMETRY_RELATION_UNKNOWN)
		return false;

	// �Ʒ��� ��쿡 �ش�Ǹ� true�� ����
	// D2D1_GEOMETRY_RELATION_IS_CONTAINED => ������ ���Ե�
	// D2D1_GEOMETRY_RELATION_CONTAINS => ������ ������
	// D2D1_GEOMETRY_RELATION_OVERLAP => ��ø�Ǵ� �κ��� ����
	return true;
}

ID2D1TransformedGeometry * IGeometry::TransformedGeometry()
{
	if (geometry == NULL)
		return NULL;

	if (D2DUtil::IsSameMatrix3x2F(transformMatrix, LastTransformMatrix))
	{
		return transformedGeometry;
	}

	SAFE_RELEASE(transformedGeometry);
	HRESULT hr = S_OK;
	hr = D2D::GetFactory()->CreateTransformedGeometry(geometry, transformMatrix, &transformedGeometry);
	assert(SUCCEEDED(hr));

	LastTransformMatrix = transformMatrix;
	return transformedGeometry;
}
