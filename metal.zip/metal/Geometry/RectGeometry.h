#pragma once

#include "IGeometry.h"

class RectGeometry : public IGeometry
{
public:
	RectGeometry();
	~RectGeometry();

	void Set(D2D1_RECT_F rect) override;
private:
	ID2D1RectangleGeometry * rectGeometry;

};

