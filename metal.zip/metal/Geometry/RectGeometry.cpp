#include "../framework.h"
#include "RectGeometry.h"

RectGeometry::RectGeometry()
	: rectGeometry(NULL)
{
}

RectGeometry::~RectGeometry()
{
	SAFE_RELEASE(rectGeometry);
}

void RectGeometry::Set(D2D1_RECT_F rect)
{
	float w = rect.right - rect.left;
	float h = rect.bottom - rect.top;

	if (w == width && h == height)
		return;

	width = w;
	height = h;

	SAFE_RELEASE(rectGeometry);

	const D2D1_RECT_F geometryRect = RectF(-width * 0.5f, -height * 0.5f,
		-width * 0.5f + width, -height * 0.5f + height);

	HRESULT hr = S_OK;
	hr = D2D::GetFactory()->CreateRectangleGeometry(geometryRect, &rectGeometry);
	assert(SUCCEEDED(hr));

	Geometry(rectGeometry);
}
