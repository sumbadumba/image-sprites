#include"../framework.h"
#include "Player.h"
#include "../Object/UVAnimation.h"
#include "../Attack/GameCharacter.h"
#include "../Attack/PlayerBullet.h"
#include "../Attack/AttackManager.h"

Player::Player()
{
	
	SetCheckScreenBound(true);//ȭ�� ������ �������� ��
}

Player::Player(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale,float movespeed  )
	:GameCharacter(pos,rot,scale,movespeed)
{
	//SetCheckScreenBound(true);
}

Player::~Player()
{

}

