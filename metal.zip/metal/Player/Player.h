#pragma once

#include "../Object/GameObject.h"

class Player : public GameObject
{
public:
	Player();
	Player(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float movespeed);

	~Player();


};

