#pragma once

#include "../Attack/GameCharacter.h"

class Player : public GameCharacter
{
public:
	Player();
	Player(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float movespeed = 50.0f);

	~Player();


private:

};

