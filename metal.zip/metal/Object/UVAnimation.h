﻿#pragma once

class UVAnimation
{
public:
	UVAnimation();
	~UVAnimation();
public:
	virtual void Update();
	virtual void Render(D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity());
	//
	void Load(wstring filePath);

	GameImage * Image() { return image; }

	D2D1_RECT_F SrcRect() { return srcRect; }

	/*
		float updateInterval : 애니메이션 업데이트 간격(초단위)
	*/
	void SetUVAnimation(UINT divideWidth, UINT divideHeight, D2D1_SIZE_F offset, float updateInterval, bool loop = false);
	bool UVAnimPlaying() { return useUVAnim; }
	bool LoopAnim() { return loopAnim; }
	void LoopAnim(bool value) { loopAnim = value; }

	UINT DivideWidth() { return divideWidth; }
	UINT DivideHeight() { return divideHeight; }

	float UpdateInterval() { return updateInterval; }

	void ResetUVAnimation();
	void UpdateUVAnimation();

private:
	GameImage * image;

	// for uv Animation
	bool useUVAnim;
	bool loopAnim;
	UINT divideWidth;
	UINT divideHeight;
	UINT xIndex;
	UINT yIndex;
	D2D1_SIZE_F uvOffset;
	float updateInterval;
	float LastUpdateTime;

	// 그려질 원본 위치의 사각형
	D2D1_RECT_F srcRect;

};

