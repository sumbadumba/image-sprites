#include "../framework.h"
#include "GameObject.h"
#include "../File/SpriteReader.h"
#include "../Geometry/RectGeometry.h"

GameObject::GameObject()
	: needScreenBoundCheck(false), moveSpeed(1.0f)
	, boundGeometry(NULL)
{
	bound = new RectBoundary();
}

GameObject::GameObject(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float moveSpeed)
	: TransformObject(pos, rot, scale), needScreenBoundCheck(false), moveSpeed(moveSpeed)
{
	bound = new RectBoundary();
}

void GameObject::Initialize()
{
	CreateBoundGeometry();
}

void GameObject::CreateBoundGeometry()
{
	boundGeometry = new RectGeometry();
}

GameObject::~GameObject()
{
	SAFE_DELETE(bound);
	SAFE_DELETE(boundGeometry);
}

void GameObject::Update()
{
	if (needMove)
		AutoMove();

	__super::Update();
}

void GameObject::UpdateDrawRect()
{
	__super::UpdateDrawRect();

	D2D1_RECT_F rect = DrawRect();
	rect.left += boundOffset.left;
	rect.top += boundOffset.top;
	rect.right += boundOffset.right;
	rect.bottom += boundOffset.bottom;

	bound->SetBondary(rect);
	//
	if (boundGeometry != NULL)
	{
		boundGeometry->Set(rect);
		boundGeometry->UpdateGeometry(position, rotation, scale);
	}
}

void GameObject::Render()
{
	__super::Render();
	if (boundGeometry != NULL)
		boundGeometry->Render();
}

void GameObject::Move(D2D1_VECTOR_2F delta)
{
	__super::Move(delta);
	CheckScreenBound();
}

void GameObject::Move(D2D_VECTOR_2F delta, vector<RectBoundary*> bounds)
{
	D2D_VECTOR_2F adjustDelta = CheckBounds(delta, bound, bounds);

	__super::Move(adjustDelta);
}

D2D_VECTOR_2F GameObject::CheckBounds(D2D_VECTOR_2F moveDelta, RectBoundary * targetBound, vector<RectBoundary*> bounds)
{
	D2D_VECTOR_2F adjustDelta;
	adjustDelta.x = adjustDelta.y = 0.0F;

	D2D_POINT_2F lefttop;
	D2D_POINT_2F righttop;
	D2D_POINT_2F leftbottom;
	D2D_POINT_2F rightbottm;

	lefttop.x = targetBound->Infimum().x + moveDelta.x;
	lefttop.y = targetBound->Infimum().y + moveDelta.y;
	righttop.x = targetBound->Supremum().x + moveDelta.x;
	righttop.y = targetBound->Infimum().y + moveDelta.y;
	leftbottom.x = targetBound->Infimum().x + moveDelta.x;
	leftbottom.y = targetBound->Supremum().y + moveDelta.y;
	rightbottm.x = targetBound->Supremum().x + moveDelta.x;
	rightbottm.y = targetBound->Supremum().y + moveDelta.y;


	D2D_VECTOR_2F delta;

	bool intersect = false;

	vector<RectBoundary*>::iterator iter = bounds.begin();
	while (iter != bounds.end())
	{
		if ((*iter) == targetBound)
		{
			iter++;
			continue;
		}
		//
		delta.x = delta.y = 0.0F;

		if (RectBoundary::CheckIntersect((*iter), lefttop))
		{
			intersect = true;
			// left
			if (moveDelta.x < 0.0f && lefttop.x <= (*iter)->Supremum().x)
			{
				// ���� ��쵵 �ٿ�� üũ�ϹǷ� �ſ� ���� ���� ���ؼ� ���Ŀ��� Y �� �̵��� �����ϵ��� ��
				delta.x = (*iter)->Supremum().x - targetBound->Infimum().x + 0.0001f * D2D::Get()->GetTargetRate().x;
				if (delta.x < adjustDelta.x)
					adjustDelta.x = delta.x;
			}
			// top
			if (moveDelta.y < 0.0f && lefttop.y <= (*iter)->Supremum().y)
			{
				// ���� ��쵵 �ٿ�� üũ�ϹǷ� �ſ� ���� ���� ���ؼ� ���Ŀ��� X �� �̵��� �����ϵ��� ��
				delta.y = (*iter)->Supremum().y - targetBound->Infimum().y + 0.0001f * D2D::Get()->GetTargetRate().y;
				if (delta.y < adjustDelta.y)
					adjustDelta.y = delta.y;
			}
		}
		else if (RectBoundary::CheckIntersect((*iter), righttop))
		{
			intersect = true;
			// right
			if (moveDelta.x > 0.0f && righttop.x >= (*iter)->Infimum().x)
			{
				delta.x = (*iter)->Infimum().x - targetBound->Supremum().x - 0.0001f * D2D::Get()->GetTargetRate().x;
				if (delta.x > adjustDelta.x)
					adjustDelta.x = delta.x;
			}
			// top
			if (moveDelta.y < 0.0f && righttop.y <= (*iter)->Supremum().y)
			{
				delta.y = (*iter)->Supremum().y - targetBound->Infimum().y + 0.0001f * D2D::Get()->GetTargetRate().y;
				if (delta.y < adjustDelta.y)
					adjustDelta.y = delta.y;
			}
		}
		else if (RectBoundary::CheckIntersect((*iter), leftbottom))
		{
			intersect = true;
			// left
			if (moveDelta.x < 0.0f && leftbottom.x <= (*iter)->Supremum().x)
			{
				delta.x = (*iter)->Supremum().x - targetBound->Infimum().x + 0.0001f * D2D::Get()->GetTargetRate().x;
				if (delta.x < adjustDelta.x)
					adjustDelta.x = delta.x;
			}
			// bottom
			if (moveDelta.y > 0.0f && leftbottom.y >= (*iter)->Infimum().y)
			{
				delta.y = (*iter)->Infimum().y - targetBound->Supremum().y - 0.0001f * D2D::Get()->GetTargetRate().y;
				if (delta.y > adjustDelta.y)
					adjustDelta.y = delta.y;
			}
		}
		else if (RectBoundary::CheckIntersect((*iter), rightbottm))
		{
			intersect = true;
			// right
			if (moveDelta.x > 0.0f && rightbottm.x >= (*iter)->Infimum().x)
			{
				delta.x = (*iter)->Infimum().x - targetBound->Supremum().x - 0.0001f * D2D::Get()->GetTargetRate().x;
				if (delta.x > adjustDelta.x)
					adjustDelta.x = delta.x;
			}
			// bottom
			if (moveDelta.y > 0.0f && rightbottm.y >= (*iter)->Infimum().y)
			{
				delta.y = (*iter)->Infimum().y - targetBound->Supremum().y - 0.0001f * D2D::Get()->GetTargetRate().y;
				if (delta.y > adjustDelta.y)
					adjustDelta.y = delta.y;
			}
		}

		iter++;
	}

	if (!intersect)
		adjustDelta = moveDelta;

	return adjustDelta;
}

void GameObject::MoveTo(D2D_POINT_2F targetPos)
{
	D2D_POINT_2F imagePos = Position();

	targetPosition.x = targetPos.x;
	targetPosition.y = targetPos.y;

	D2D_VECTOR_3F vector3;
	vector3.x = targetPos.x - imagePos.x;
	vector3.y = targetPos.y - imagePos.y;
	vector3.z = 0.0f;

	// �Ÿ��� ���Ѵ�
	float distance = D2D1Vec3Length(vector3.x, vector3.y, vector3.z);
	// ���� ����ȭ(normalize)
	moveDirection.x = vector3.x / distance;
	moveDirection.y = vector3.y / distance;

	needMove = true;
}

void GameObject::CheckScreenBound()
{
	if (!needScreenBoundCheck)
		return;

	UpdateDrawRect();

	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();

	D2D_RECT_F rect = DrawRect();

	D2D1_VECTOR_2F adjustDelta;
	adjustDelta.x = adjustDelta.y = 0.0F;

	if (rect.left < 0)
		adjustDelta.x += -rect.left;
	else if (rect.right >= renderTargetSize.width)
	{
		// �ܰ� üũ�� Size ������ �ǹ̿� ���� +1 �ؾ� �� �� �ִ�
		//adjustDelta.x -= rect.right - renderTargetSize.width + 1;
		adjustDelta.x -= rect.right - renderTargetSize.width;
	}

	if (rect.top < 0)
		adjustDelta.y += -rect.top;
	else if (rect.bottom >= renderTargetSize.height)
	{
		// �ܰ� üũ�� Size ������ �ǹ̿� ���� +1 �ؾ� �� �� �ִ�
		//adjustDelta.y -= rect.bottom - renderTargetSize.height + 1;
		adjustDelta.y -= rect.bottom - renderTargetSize.height;
	}

	__super::Move(adjustDelta);
}

bool GameObject::LoadSprite(wstring filePath)
{
	SpriteReader * reader = new SpriteReader(this);
	bool result = reader->Load(filePath);
	SAFE_DELETE(reader);
	return result;
}

void GameObject::AutoMove()
{
	D2D_VECTOR_2F delta;

	float deltaTime = Time::Delta();

	delta.x = moveDirection.x * moveSpeed * deltaTime;
	delta.y = moveDirection.y * moveSpeed * deltaTime;

	// �Ÿ��� 1���� �϶� delta�� ��������
	D2D_POINT_2F imagePos = Position();

	D2D_VECTOR_3F vector3;
	vector3.x = targetPosition.x - imagePos.x;
	vector3.y = targetPosition.y - imagePos.y;
	vector3.z = 0.0f;

	// �Ÿ��� 1 �����ΰ��
	float distance = D2D1Vec3Length(vector3.x, vector3.y, vector3.z);
	if (distance < 1.0f)
	{
		delta.x = vector3.x;
		delta.y = vector3.y;

		needMove = false;
	}

	////////////////////////////////////////////////////
	// ����ġ�� �Ǵ� ���
	if (delta.x > 0 && imagePos.x + delta.x > targetPosition.x)
	{
		delta.x = targetPosition.x - imagePos.x;
		needMove = false;
	}
	else if (delta.x < 0 && imagePos.x + delta.x < targetPosition.x)
	{
		delta.x = targetPosition.x - imagePos.x;
		needMove = false;
	}

	if (delta.y > 0 && imagePos.y + delta.y > targetPosition.y)
	{
		delta.y = targetPosition.y - imagePos.y;
		needMove = false;
	}
	else if (delta.y < 0 && imagePos.y + delta.y < targetPosition.y)
	{
		delta.y = targetPosition.y - imagePos.y;
		needMove = false;
	}

	__super::Move(delta);
}
