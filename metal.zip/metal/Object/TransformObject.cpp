#include "../framework.h"
#include "./TransformObject.h"
#include "./UVAnimation.h"
#include "../File/SpriteReader.h"

TransformObject::TransformObject()
	: position(Point2F()), rotation(0.0f), scale(Vector2F(1.0f, 1.0f)), active(true), enableRender(true)
	, animationObject(NULL)
{
	scaleMatrix = Matrix3x2F::Identity();
	rotationMatrix = Matrix3x2F::Identity();
	translationMatrix = Matrix3x2F::Identity();
	UpdateMatrix();
}

TransformObject::TransformObject(D2D1_POINT_2F pos, FLOAT rot, D2D1_VECTOR_2F scale)
	: position(pos), rotation(rot), scale(scale), active(true), enableRender(true)
{
	scaleMatrix = Matrix3x2F::Scale(scale.x, scale.y);
	rotationMatrix = Matrix3x2F::Rotation(rotation, position);
	translationMatrix = Matrix3x2F::Translation(position.x, position.y);
	UpdateMatrix();
}

TransformObject::~TransformObject()
{
	SAFE_DELETE(animationObject);
}

void TransformObject::Update()
{
	if (!active)
		return;

	UpdateDrawRect();
	if (animationObject != NULL)
		animationObject->Update();
}

void TransformObject::UpdateDrawRect()
{
	if (animationObject == NULL)
		return;

	// drawRect �� �̸� ���
	D2D1_RECT_F srcRect = animationObject->SrcRect();
	float width = (srcRect.right - srcRect.left) * scale.x;
	float height = (srcRect.bottom - srcRect.top) * scale.y;

	drawRect.left = (position.x - width * 0.5f);
	drawRect.top = (position.y - height * 0.5f);
	drawRect.right = (drawRect.left + width);
	drawRect.bottom = (drawRect.top + height);

	drawRect = NORMALIZE_RECT_F(drawRect);
}

void TransformObject::Render()
{
	if (!active || !enableRender || animationObject == NULL)
		return;

	D2D1_RECT_F rect;

	D2D1_RECT_F srcRect = animationObject->SrcRect();
	float width = (srcRect.right - srcRect.left);
	float height = (srcRect.bottom - srcRect.top);

	rect.left = (-width * 0.5f);
	rect.top = (-height * 0.5f);
	rect.right = (rect.left + width);
	rect.bottom = (rect.top + height);

	animationObject->Render(rect, transformMatrix);
}

void TransformObject::Load(wstring filePath)
{
	animationObject = new UVAnimation();
	animationObject->Load(filePath);
	
}

void TransformObject::Position(D2D1_POINT_2F val)
{
	position = val;
	translationMatrix = Matrix3x2F::Translation(position.x, position.y);
	UpdateMatrix();
}

void TransformObject::Rotate(FLOAT delta, D2D1_POINT_2F rotPoint)
{
	rotation += delta;

	rotationMatrix = Matrix3x2F::Rotation(rotation, rotPoint);
	UpdateMatrix();
}

void TransformObject::Scale(D2D1_VECTOR_2F val)
{
	scale = val;
	scaleMatrix = Matrix3x2F::Scale(scale.x, scale.y);
	UpdateMatrix();
}

void TransformObject::Scaling(D2D1_VECTOR_2F delta)
{
	scale.x += delta.x;
	scale.y += delta.y;
	scaleMatrix = Matrix3x2F::Scale(scale.x, scale.y);
	UpdateMatrix();
}

void TransformObject::UpdateMatrix()
{
	transformMatrix.SetProduct(scaleMatrix, rotationMatrix);
	transformMatrix.SetProduct(transformMatrix, translationMatrix);
}

void TransformObject::Move(D2D1_VECTOR_2F delta)
{
	position.x += delta.x;
	position.y += delta.y;
	translationMatrix = Matrix3x2F::Translation(position.x, position.y);
	UpdateMatrix();
}