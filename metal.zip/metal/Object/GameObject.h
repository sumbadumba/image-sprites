#pragma once

#include "TransformObject.h"

class GameObject : public TransformObject
{
public:
	GameObject();
	GameObject(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float moveSpeed = 50.0f);
	~GameObject();

	virtual void Initialize();
	virtual void CreateBoundGeometry();

	void Update();
	void UpdateDrawRect();

	void Render();

	void Move(D2D1_VECTOR_2F delta);
	void Move(D2D_VECTOR_2F delta, vector<RectBoundary*> bounds);
	//
	void SetCheckScreenBound(bool value) { needScreenBoundCheck = value; }
	D2D_VECTOR_2F CheckBounds(D2D_VECTOR_2F moveDelta, RectBoundary * bound, vector<RectBoundary*> bounds);

	RectBoundary * Bound() { return bound; }
	IGeometry * BoundGeometry() { return boundGeometry; }
	D2D1_RECT_F BoundOffset() { return boundOffset; }
	void BoundOffset(D2D1_RECT_F value) { boundOffset = value; }

	void MoveTo(D2D_POINT_2F targetPos);

	bool NeedMove() { return needMove; }
	void MoveSpeed(float value) { moveSpeed = value; }
	bool LoadSprite(wstring filePath);
private:
	void AutoMove();
	void CheckScreenBound();
protected:
	IGeometry * boundGeometry;

private:
	bool needScreenBoundCheck;

	class RectBoundary * bound;
	D2D1_RECT_F boundOffset;

	D2D_VECTOR_2F targetPosition;
	D2D_VECTOR_2F moveDirection;
	float moveSpeed;

	bool needMove;



};

