#pragma once

struct D2DDesc
{
	wstring AppName;
	HINSTANCE Instance;
	HWND Handle;
	UINT Width;
	UINT Height;
	bool bVsync;
	bool bFullScreen;
};

class D2D
{
// �����ڿ� �Ҹ���
private:
	D2D();
	~D2D();

	/////////////////////////////////////
	// �ֿ� �������
	/////////////////////////////////////
	static D2D* instance;	// �̱���ȭ

	static D2DDesc d2dDesc;

	static ID2D1Factory * D2DFactory;
	static IWICImagingFactory * WICFactory;
	static IDWriteFactory * DWriteFactory;
	static ID2D1HwndRenderTarget * RenderTarget;


	static D2D_VECTOR_2F RenderTargetRate;

// �ܺ� ���ٿ� �޼ҵ�
public:
	static D2D* Get();
	static void Create();
	static void Delete();

	static void GetDesc(D2DDesc* desc)
	{
		*desc = d2dDesc;
	}

	static void SetDesc(D2DDesc& desc)
	{
		d2dDesc = desc;
	}

	static ID2D1Factory * GetFactory()
	{
		return D2DFactory;
	}
	
	static IWICImagingFactory * GetWICFactory()
	{
		return WICFactory;
	}

	static IDWriteFactory * GetWriteFactory()
	{
		return DWriteFactory;
	}

	static ID2D1HwndRenderTarget * GetRenderTarget()
	{
		return RenderTarget;
	}
	static D2D_VECTOR_2F GetTargetRate()
	{
		return RenderTargetRate;
	}

	void ResizeScreen(UINT width, UINT height);

	static void BeginDraw();
	static void SetTransform(const D2D1_MATRIX_3X2_F &transform);
	static void Clear(const D2D1_COLOR_F &clearColor);
	static HRESULT EndDraw();
	static HRESULT Flush();

private:
	static HRESULT CreateDeviceIndependentResources();
	static HRESULT CreateDeviceResources();
	static void CalculateTargetRate();

};