#pragma once

enum INTERSECT_TYPE
{
	NONE = 0,
	LEFTTOP,
	RIGHTTOP,
	LEFTBOTTOM,
	RIGHTBOTTOM,
	INSIDE,
};

// Rotate rect is not supported.
class RectBoundary
{
public:
	RectBoundary();
	~RectBoundary();

	void SetBondary(D2D_RECT_F rect);
	void SetBondary(D2D_POINT_2F inf, D2D_POINT_2F sup);
	void SetBondary(FLOAT left, FLOAT top, FLOAT right, FLOAT bottom);

	static bool CheckIntersect(RectBoundary * boundary, D2D_POINT_2F position);
	static bool CheckIntersect(RectBoundary * boundary1, RectBoundary * boundary2);

	INTERSECT_TYPE CheckIntersect(RectBoundary * other);

	D2D_POINT_2F Infimum() { return infimum; }
	D2D_POINT_2F Supremum() { return supremum; }


private:
	D2D_POINT_2F infimum; //left-top
	D2D_POINT_2F supremum; //right-bottom

};