﻿#include "framework.h"
#include "Systems/Window.h"

#define MAX_LOADSTRING 100

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: 여기에 코드를 입력합니다.

	D2DDesc desc;
	desc.AppName = L"Metal_slug";
	desc.Instance = hInstance;
	desc.bFullScreen = false;
	desc.bVsync = false;
	desc.Handle = NULL;
	desc.Width = 900;
	desc.Height = 700;
	D2D::SetDesc(desc);

	WPARAM wParam = 0x0;
	if (SUCCEEDED(CoInitialize(NULL)))
	{
		Window* window = new Window();
		wParam = window->Run();
		SAFE_DELETE(window);
		CoUninitialize();
	}
	return (int)wParam;
}
