#pragma once

class SpriteReader
{
public:
	SpriteReader(class GameObject * object);
	~SpriteReader();

	bool Load(wstring filePath);
private:
	void ReadLoopImageFilePath(Xml::XMLElement * node);
	D2D1_SIZE_U ReadLoopDivide(Xml::XMLElement * node);
	bool ReadLoopAnim(Xml::XMLElement * node);
	float ReadUpdateInterval(Xml::XMLElement * node);
	void ReadBoundoffset(Xml::XMLElement * node);
private:
	class GameObject * object;
	class GameImage * image;
};

