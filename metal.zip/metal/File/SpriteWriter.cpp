#include "../framework.h"
#include "SpriteWriter.h"
#include "../Object/GameObject.h"
#include "../Object/UVAnimation.h"

SpriteWriter::SpriteWriter(GameObject * object)
	: object(object)
{
	image = object->AnimationObject()->Image();
}

SpriteWriter::~SpriteWriter()
{

}

void SpriteWriter::Write(wstring saveFolder, wstring fileName)
{
	Path::CreateFolders(saveFolder);

	Xml::XMLDocument * document = new Xml::XMLDocument();
	Xml::XMLDeclaration * decl = document->NewDeclaration();
	document->LinkEndChild(decl);

	Xml::XMLElement * root = document->NewElement("Sprite");
	root->SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
	root->SetAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
	document->LinkEndChild(root);
	//
	AddLoopImageFilePath(document, root);
	AddLoopDivide(document, root);
	AddLoopAnim(document, root);
	AddBoundoffset(document, root);
	//
	string file = String::ToString(saveFolder + fileName);
	document->SaveFile(file.c_str());
}

void SpriteWriter::AddLoopImageFilePath(Xml::XMLDocument * document, Xml::XMLElement * parent)
{
	Xml::XMLElement * element = document->NewElement("ImageFilePath");
	parent->LinkEndChild(element);
	element->SetText(String::ToString(image->FilePath()).c_str());
}

void SpriteWriter::AddLoopDivide(Xml::XMLDocument * document, Xml::XMLElement * parent)
{
	Xml::XMLElement * element = document->NewElement("Divide");
	parent->LinkEndChild(element);
	element->SetAttribute("Width", object->AnimationObject()->DivideWidth());
	element->SetAttribute("Height", object->AnimationObject()->DivideHeight());
}

void SpriteWriter::AddLoopAnim(Xml::XMLDocument * document, Xml::XMLElement * parent)
{
	Xml::XMLElement * element = NULL;
	element = document->NewElement("LoopAnim");
	parent->LinkEndChild(element);
	element->SetAttribute("Value", object->AnimationObject()->LoopAnim());
	element->SetAttribute("UpdateInterval", object->AnimationObject()->UpdateInterval());
}

void SpriteWriter::AddBoundoffset(Xml::XMLDocument * document, Xml::XMLElement * parent)
{
	Xml::XMLElement * element = document->NewElement("BoundOffset");
	parent->LinkEndChild(element);

	D2D1_RECT_F boundOffset = object->BoundOffset();
	element->SetAttribute("Left", boundOffset.left);
	element->SetAttribute("Top", boundOffset.top);
	element->SetAttribute("Right", boundOffset.right);
	element->SetAttribute("Bottom", boundOffset.bottom);
}