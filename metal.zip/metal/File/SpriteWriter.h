#pragma once

class SpriteWriter
{
public:
	SpriteWriter(class GameObject * object);
	~SpriteWriter();

	void Write(wstring saveFolder, wstring fileName);
private:
	void AddLoopImageFilePath(Xml::XMLDocument * document, Xml::XMLElement * parent);
	void AddLoopDivide(Xml::XMLDocument * document, Xml::XMLElement * parent);
	void AddLoopAnim(Xml::XMLDocument * document, Xml::XMLElement * parent);
	void AddBoundoffset(Xml::XMLDocument * document, Xml::XMLElement * parent);
private:
	class GameObject * object;
	class GameImage * image;
};

