#pragma once

#include "ImageEffect.h"

class Shadow : public ImageEffect
{
public:
	Shadow();
	~Shadow();

	void SetBlurStandardDeviation(float StDev);
	void Translation(FLOAT x, FLOAT y);

	void Render(class Image * image, D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity()) override;

private:

	const float DefaultBlurStandardDeviation = 5.0f;

	D2D1_COLOR_F Color;

	ID2D1Effect * AffineTransformEffect;
	D2D1_POINT_2F Distance;


};

