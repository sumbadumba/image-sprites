#include "../framework.h"
#include "GaussianBlur.h"

GaussianBlur::GaussianBlur()
	: ImageEffect(CLSID_D2D1GaussianBlur)
{
	Effect->SetValue(D2D1_GAUSSIANBLUR_PROP_BORDER_MODE, D2D1_BORDER_MODE_SOFT);
	Effect->SetValue(D2D1_GAUSSIANBLUR_PROP_STANDARD_DEVIATION, DefaultStDev);
}

GaussianBlur::~GaussianBlur()
{

}

void GaussianBlur::SetStandardDeviation(float StDev)
{
	Effect->SetValue(D2D1_GAUSSIANBLUR_PROP_STANDARD_DEVIATION, StDev);
}
