#pragma once

class ImageEffect
{
public:
	ImageEffect(REFCLSID clsID);
	~ImageEffect();
protected:
	ID2D1DeviceContext * DeviceContext;
	ID2D1BitmapRenderTarget * BitmapRenderTarget;
	//
	ID2D1Effect * Effect;
	D2D1_INTERPOLATION_MODE interplationMode;
	D2D1_POINT_2F targetOffset;

public:
	virtual void Render(class Image * image, D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity());

	D2D1_POINT_2F TargetOffset() { return targetOffset; }
	void TargetOffset(D2D1_POINT_2F val) { targetOffset = val; }


};

