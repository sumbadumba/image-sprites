#pragma once

#include "ImageEffect.h"

class Border : public ImageEffect
{
public:
	Border();
	~Border();

	void SetEdgeMode(D2D1_BORDER_EDGE_MODE ModeX, D2D1_BORDER_EDGE_MODE ModeY);
private:

};

