#include "../framework.h"
#include "Border.h"

Border::Border()
	: ImageEffect(CLSID_D2D1Border)
{
	Effect->SetValue(D2D1_BORDER_PROP_EDGE_MODE_X, D2D1_BORDER_EDGE_MODE_WRAP);
	Effect->SetValue(D2D1_BORDER_PROP_EDGE_MODE_Y, D2D1_BORDER_EDGE_MODE_WRAP);
}

Border::~Border()
{

}

void Border::SetEdgeMode(D2D1_BORDER_EDGE_MODE ModeX, D2D1_BORDER_EDGE_MODE ModeY)
{
	Effect->SetValue(D2D1_BORDER_PROP_EDGE_MODE_X, ModeX);
	Effect->SetValue(D2D1_BORDER_PROP_EDGE_MODE_Y, ModeY);
}
