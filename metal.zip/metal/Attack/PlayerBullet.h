#pragma once

#define PLAYER_BULLET_SPRITE Sprites + L"Bullet_Player.spr"
#define PLAYER_BULLET_SPEED 300.0f

#include "AttackManager.h"

class PlayerBullet : public AttackManager
{
public:

	PlayerBullet();
	~PlayerBullet();

	//void Update(class Enemy * enemy);

	//void Shoot(class Enemy * enemy);

private:
	bool Erase(class Bullets * bullets);


};

