#pragma once

#define BULLET_IMAGE1 L"../../Image/Bullet_Image/Bullet_10_10.png"
#define BULLET_SPEED 300.0f

#include "AttackManager.h"

class PlayerBullet : public AttackManager
{
	PlayerBullet();

	~PlayerBullet();

	void Render();
	void Update();

	void Shoot();

private:


};

