#pragma once

#include "GameCharacter.h"

class Shooting : public GameCharacter
{
public:
	Shooting();
	Shooting(D2D_POINT_2F pos, FLOAT rot, D2D1_VECTOR_2F scale, float movespeed = 50.0f);

	~Shooting();


private:

};

