#include "../framework.h"
#include "Bullets.h"
#include"../Object/UVAnimation.h"
#include "../Geometry/EllipseGeometry.h"

Bullets::Bullets()
{
	CreateBoundGeometry();
}

Bullets::~Bullets()
{
	
}

void Bullets::CreateBoundGeometry()
{
	boundGeometry = new EllipseGeometry();

}
