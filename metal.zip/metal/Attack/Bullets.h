#pragma once

#include "Shooting.h"


class Bullets : public Shooting
{
public:
	Bullets();
	~Bullets();

	void CreateBoundGeometry();

};

