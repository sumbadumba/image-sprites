#include "../framework.h"
#include "GameCharacter.h"
#include "./Shooting.h"

Shooting::Shooting()
{

}

Shooting::Shooting(D2D_POINT_2F pos, FLOAT rot, D2D1_VECTOR_2F scale, float movespeed)
{

}

Shooting::~Shooting()
{
}
