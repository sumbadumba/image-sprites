#pragma once



class AttackManager
{
public:
	
	AttackManager();
	~AttackManager();

	void Update();
	void Render();

	void Attack();

protected:
	TPool<class PlayerBullet> pool;
	list<class PlayerBullet *> activeBullet;


};

