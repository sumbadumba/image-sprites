#pragma once

#define BULLET_POOL_COUNT 30
#define PLAYER_BULLET_FILEPATH Images + L"Bullet_Image/Bullet_10_10.png"
#define PLAYER_BULLET_ANIM_INTERVAL 0.03f
#define PLAYER_BULLET_UVCOUNT_X 1
#define PLAYER_BULLET_UVCOUNT_Y 1
#define PLAYER_BULLET_UVOFFSET 100f



#define DEFAULT_BULLET_MOVE_SPEED 100.0f
#define DEFAULT_BULLET_FILEPATH Sprites + L"Bullet_Player.spr"


class AttackManager
{
public:
	
	AttackManager(wstring bulletFilePath = DEFAULT_BULLET_FILEPATH, float moveSpeed = DEFAULT_BULLET_MOVE_SPEED);
	~AttackManager();

	void Update();
	void Render();

	void Shoot(D2D1_POINT_2F pos, D2D1_VECTOR_2F direction);


protected:
	TPool<class Bullets> pool;
	list<class Bullets *> activeBullet;

	wstring bulletFilePath;
	float moveSpeed = 50.0f;

};

