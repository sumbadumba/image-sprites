#include "../framework.h"
#include "./AttackManager.h"
#include "./Bullets.h"
#include "../File/SpriteReader.h"
#include "../Object/UVAnimation.h"
#include "../Attack/GameCharacter.h"

AttackManager::AttackManager(wstring bulletFilePath, float moveSpeed)
	:bulletFilePath(bulletFilePath), moveSpeed(moveSpeed)

{
	pool.Generate(BULLET_POOL_COUNT);
}



AttackManager::~AttackManager()
{
	Bullets * ptr = nullptr;
	while (!activeBullet.empty())
	{
		ptr = activeBullet.front();
		activeBullet.pop_front();
		pool.Release(ptr);
	}

	pool.Delete();

}
 
void AttackManager::Update()
{
	Bullets * ptr = nullptr;

	list<Bullets *>::iterator iter = activeBullet.begin();

	while (iter != activeBullet.end())
	{
		(*iter)->Update();
		if (!(*iter)->NeedMove())
		{
			ptr = (*iter);
			activeBullet.erase(iter++);
			pool.Release(ptr);
			continue;

		}
		iter++;
	}
}

void AttackManager::Render()
{
	list<Bullets *>::iterator iter = activeBullet.begin();
	while (iter != activeBullet.end())
	{
		(*iter)->Render();
		iter++;

	}
}

void AttackManager::Shoot(D2D1_POINT_2F pos, D2D1_VECTOR_2F direction)
{
	Bullets * bullets;
	bullets = pool.Acquire();

	if (bullets == nullptr)
	{
		DebugPrint(L"BulletManager not enough bullet! \n");
		return;
	}
	if (bullets->AnimationObject() == NULL)
	{
		SpriteReader * reader = new SpriteReader(bullets);
		reader->Load(bulletFilePath);
		SAFE_DELETE(reader);
	}

	bullets->Load(PLAYER_BULLET_FILEPATH);
	bullets->Position(pos);


	bullets->MoveSpeed(DEFAULT_BULLET_MOVE_SPEED);
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D1_POINT_2F targetPos;



	if (abs(direction.x) > 0.0f)
		targetPos.x = pos.x + direction.x / abs(direction.x) * renderTargetSize.width + bullets->AnimationObject()->Image()->ImageSize().width;
	else
		targetPos.x = pos.x;


	if (abs(direction.y) > 0.0f)
		targetPos.x = pos.y + direction.y / abs(direction.y) * renderTargetSize.height + bullets->AnimationObject()->Image()->ImageSize().height;
	else
		targetPos.y = pos.y;

	bullets->MoveTo(targetPos);

	bullets->UpdateDrawRect();

	activeBullet.push_back(bullets);


}

