#include "../framework.h"
#include "AttackManager.h"

AttackManager::AttackManager()
{
}

AttackManager::~AttackManager()
{
}

void AttackManager::Update()
{
}

void AttackManager::Render()
{
}

void AttackManager::Attack()
{
}
