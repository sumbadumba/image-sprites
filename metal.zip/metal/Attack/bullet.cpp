#include "../framework.h"
#include "./bullet.h"


bullet::bullet()
{

}

bullet::~bullet()
{


}