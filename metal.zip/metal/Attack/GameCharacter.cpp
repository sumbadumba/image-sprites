#include "../framework.h"
#include "GameCharacter.h"
#include "../Geometry/EllipseGeometry.h"
#include "../File/SpriteReader.h"

GameCharacter::GameCharacter()
{
	Initialize();
}

GameCharacter::GameCharacter(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float moveSpeed)
	: GameObject(pos, rot, scale, moveSpeed)
{

}

GameCharacter::~GameCharacter()
{
}

void GameCharacter::Initialize()
{
	__super::Initialize();

}


//void GameCharacter::CreateBoundGeometry()
//{
//	boundGeometry = new EllipseGeometry();
//}

bool GameCharacter::LoadSprite(wstring filePath)
{
	SpriteReader * reader = new SpriteReader(this);
	bool result = reader->Load(filePath);
	SAFE_DELETE(reader);
	return result;
}
//bool GameCharacter::Intersect(GameObject * other)
//{
//	return BoundGeometry()->Intersect(other->BoundGeometry());
//
//}
