#pragma once
class Grenade
{
};

