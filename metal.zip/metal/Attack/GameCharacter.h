#pragma once

#include "../Object/GameObject.h"

class GameCharacter : public GameObject
{
public:
	GameCharacter();
	GameCharacter(D2D_POINT_2F pos, FLOAT rot, D2D_VECTOR_2F scale, float moveSpeed = 50.0f);
	~GameCharacter();

	void Initialize() override;

	//void CreateBoundGeometry() override;

	bool LoadSprite(wstring filePath);

	//bool Intersect(GameObject * other);


private:



};

