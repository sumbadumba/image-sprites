#include "../framework.h"
#include "PlayerBullet.h"
#include "./Bullets.h"

PlayerBullet::PlayerBullet()
	:AttackManager(PLAYER_BULLET_SPRITE, PLAYER_BULLET_SPEED)
{
	pool.Generate(BULLET_POOL_COUNT);
}

PlayerBullet::~PlayerBullet()
{
}

//void PlayerBullet::Update(Enemy * enemy)
//{
//	list<Bullets *> intersectList;
//	UINT enemyCount = enemy->ActiveCount();
//
//}

bool PlayerBullet::Erase(Bullets * bullets)
{
	list<Bullets *>::iterator iter = activeBullet.begin();
	while (iter != activeBullet.end())
	{
		if ((*iter) == bullets)
		{
			activeBullet.erase(iter);
			return true;

		}
		iter++;

	}
	return false;


}
