#include "../framework.h"
#include "PlayerBullet.h"
#include "bullet.h"

PlayerBullet::PlayerBullet()
{

}


PlayerBullet::~PlayerBullet()
{
}

void PlayerBullet::Render()
{
}

void PlayerBullet::Update()
{
}

void PlayerBullet::Shoot()
{
}

