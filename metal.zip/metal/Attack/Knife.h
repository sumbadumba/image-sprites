#pragma once
class Knife
{
};

