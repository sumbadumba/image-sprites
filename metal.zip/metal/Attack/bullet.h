#pragma once

#include "../Object/GameObject.h"

class bullet : public GameObject
{
public: 
	bullet();
	~bullet();



};

