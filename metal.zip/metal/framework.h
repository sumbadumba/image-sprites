﻿// header.h: 표준 시스템 포함 파일
// 또는 프로젝트 특정 포함 파일이 들어 있는 포함 파일입니다.
//

#pragma once

#include "targetver.h"
//////////////////////////////////////////////////////////////////////////////////////////
//#define WIN32_LEAN_AND_MEAN             // 거의 사용되지 않는 내용을 Windows 헤더에서 제외합니다.
//////////////////////////////////////////////////////////////////////////////////////////
// Windows 헤더 파일
#include <windows.h>
#include <assert.h>

// C 런타임 헤더 파일입니다.
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

//STL
#include <string>
#include <vector>
#include <list>
#include <map>
#include <queue>
#include <unordered_map>
#include <functional>
#include <math.h>

using namespace std;

// d2d1.h 가 기본 베이스 Windows SDK에 존재
// Windows 8 이상의 호환성 문제가 있는경우 d2d1_1.h 이상 사용
// 아래 폴더에 존재
// Program Files (x86)\Windows Kits\10\Include\버전\um
#include <d2d1_1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#include <wincodec.h>

using namespace D2D1;

// 링크시 lib를 추가하는 방법중 하나. 다른방법은 프로젝트 속성에서 입력
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "windowscodecs.lib")

#include <atlbase.h>

// Sound
#include <mmsystem.h>

#pragma comment(lib, "winmm.lib")

const wstring Images = L"../../Image/";
const wstring Sprites = L"../../Sprite/";

#define SAFE_RELEASE(p) { if(p){ (p)->Release(); (p) = NULL; } }
#define SAFE_RELEASE_COM(p) { if(p){ (p).Release(); (p) = NULL; } }
#define SAFE_DELETE(p) { if(p){ delete (p); (p) = NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p){ delete [] (p); (p) = NULL; } }

#include "./Systems/D2D.h"
#include "./Systems/Keyboard.h"
#include "./Systems/Mouse.h"
#include "./Systems/Time.h"
#include "./Systems/RectBoundary.h"
#include "./Systems/TPool.h"

#include "./Utilities/Math.h"
#include "./Utilities/String.h"
#include "./Utilities/Path.h"
#include "./Utilities/Xml.h"
#include "./Utilities/DebugUtil.h"
#include "./Utilities/D2DUtil.h"

#include "./Image/Image.h"
#include "./Image/GameImage.h"
#include "./Image/ImageCache.h"

#include "./Geometry/IGeometry.h"

#include "Exe/Exe.h"


#ifndef Assert
#if defined( DEBUG ) || defined( _DEBUG )
#define Assert(b) if (!(b)) { DebugUtil::AssertPrint("Assert: " #b, __FILE__, __LINE__);}
#else
#define Assert(b)
#endif //DEBUG || _DEBUG
#endif

#define NORMALIZE_VECTOR_F(p) D2DUtil::NomalizeVector2F(p)
#define NORMALIZE_POINT_F(p) D2DUtil::NomalizePoint2F(p)
#define NORMALIZE_POINT_U(p) D2DUtil::NomalizePoint2U(p)
#define NORMALIZE_RECT_F(p) D2DUtil::NomalizeRectF(p)
#define NORMALIZE_RECT_U(p) D2DUtil::NomalizeRectU(p)
#define NORMALIZE_SIZE_F(p) D2DUtil::NomalizeSizeF(p)
#define NORMALIZE_SIZE_U(p) D2DUtil::NomalizeSizeU(p)
