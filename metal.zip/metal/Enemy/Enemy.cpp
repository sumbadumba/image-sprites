#include "../framework.h"

#include "Enemy.h"
#include "../Attack/GameCharacter.h"

Enemy::Enemy()
{
	

}

Enemy::~Enemy()
{

}

