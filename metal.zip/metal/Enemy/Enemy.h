#pragma once

#include "../Attack/GameCharacter.h"

class Enemy : public GameCharacter
{
public:
	Enemy();
	~Enemy();

private:
};

