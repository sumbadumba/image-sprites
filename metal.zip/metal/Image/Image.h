﻿#pragma once
class Image
{
public:
	Image();
	~Image();
private:
	static const FLOAT Opacity;

public:
	virtual void Update();

	virtual void Render(D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity());
	void RenderBitmapTarget(ID2D1BitmapRenderTarget * bitmapRenderTarget, D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity());

	//
	virtual void Load(wstring filePath);

	D2D1_SIZE_F ImageSize() { return imageSize; }

	void InterpolationMode(D2D1_BITMAP_INTERPOLATION_MODE value)
	{
		interpolationMode = value;
	}

	IWICFormatConverter * GetFormatConverter()
	{
		return FormatConverter;
	}

	ID2D1Bitmap * GetBitmap()
	{
		return Bitmap;
	}

	wstring FilePath() { return filePath; }

	D2D1_RECT_F SrcRect() { return srcRect; }
	void SrcRect(D2D1_RECT_F value) { srcRect = value; }

protected:
	// 그려질 원본 위치의 사각형
	D2D1_RECT_F srcRect;

	// 회전 값
	FLOAT rotation;

	//배율
	D2D1_VECTOR_2F scale;


private:
	// 이미지 파일 해석용 인터페이스
	IWICBitmapDecoder * ImageDecoder = NULL;
	// 프레임단위로 해석할 디코더 인터페이스
	IWICBitmapFrameDecode * WicFrameDecoder = NULL;
	// 이미지형식 변환 인터페이스
	IWICFormatConverter * FormatConverter = NULL;


	// Direct2D 용 비트맵 객체 인터페이스​
	ID2D1Bitmap * Bitmap = NULL;
	// 이미지 원본 크기
	D2D1_SIZE_F imageSize;

	D2D1_BITMAP_INTERPOLATION_MODE interpolationMode;

	wstring filePath;
};

