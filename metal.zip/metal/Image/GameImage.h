﻿#pragma once

#include "Image.h"

class GameImage : public Image
{
public:
	GameImage();
	~GameImage();

	void Render(D2D1_RECT_F drawRect, Matrix3x2F transformMatrix = Matrix3x2F::Identity()) override;
	//
	void AddEffect(class ImageEffect* effect) { imageEffect = effect; }

	wstring FilePath() { return filePath; }
	void FilePath(wstring value) { filePath = value; }


protected:
	class ImageEffect* imageEffect;

private:
	wstring filePath;


};

