#pragma once

class ImageCache
{
private:
	static ImageCache* instance;
public:
	static ImageCache* Get();

	static void Create();
	static void Delete();

private:
	typedef struct Struct
	{
		GameImage * image;
		wstring filePath;
		UINT refCount;
	} CacheData;

public:
	ImageCache();
	~ImageCache();

	GameImage * Load(wstring filePath);
	bool Unload(GameImage * image);

private:
	unordered_map<wstring, CacheData> caches;
};

