#include "../framework.h"
#include "ImageCache.h"
#include "GameImage.h"

ImageCache* ImageCache::instance = NULL;

ImageCache * ImageCache::Get()
{
	assert(instance != NULL);

	return instance;
}

void ImageCache::Create()
{
	assert(instance == NULL);

	instance = new ImageCache();
}

void ImageCache::Delete()
{
	SAFE_DELETE(instance);
}

ImageCache::ImageCache()
{
}

ImageCache::~ImageCache()
{
	unordered_map<wstring, CacheData>::iterator iter = caches.begin();
	
	while (iter != caches.end())
	{
		DebugPrint(L"image isn't unloaded! filePath = %s \n", iter->second.filePath.c_str());
		SAFE_DELETE(iter->second.image);
		iter++;
	}
	caches.clear();
}

GameImage * ImageCache::Load(wstring filePath)
{
	unordered_map<wstring, CacheData>::iterator iter = caches.find(filePath);

	if (iter != caches.end())
	{
		iter->second.refCount++;
		return iter->second.image;
	}

	CacheData data;
	data.filePath = filePath;
	data.image = new GameImage();
	data.image->Load(filePath);
	data.refCount = 1;
	caches.insert(unordered_map<wstring, CacheData>::value_type(filePath, data));

	return data.image;
}

bool ImageCache::Unload(GameImage * image)
{
	wstring filePath = image->FilePath();

	unordered_map<wstring, CacheData>::iterator iter = caches.find(filePath);

	if (iter == caches.end())
	{
		DebugPrint(L"ImageCache::Unload error! filePath = %s \n", filePath.c_str());
		return false;
	}

	iter->second.refCount--;

	if (iter->second.refCount <= 0)
	{
		SAFE_DELETE(iter->second.image);
		caches.erase(iter);
	}

	return true;
}