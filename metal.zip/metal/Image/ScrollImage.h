﻿#pragma once

#include "GameImage.h"

class ScrollImage : public GameImage
{
public:
	ScrollImage(D2D1_POINT_2F scrollSpeed);
	~ScrollImage();
private:
	D2D1_POINT_2F scrollSpeed;
public:
	void Update() override;

	//int GetMaxHP() { return MaxHP; }
	//void SetMaxHP(int value) { MaxHP = value; }

	D2D_VECTOR_2F GetDelta() { return delta; }
	void SetDelta(D2D_VECTOR_2F value) { delta = value; }

	bool Get() { return sc_check; }
	void Set(bool value) { sc_check = value; }

	D2D1_POINT_2F GetSpeed() { return  ch_scrollSpeed; }

	void SetSpeed(D2D1_POINT_2F value) {
		ch_scrollSpeed = value;
	}

	//class TransformObject AnimationTransform() { return transform; }
private:
	//class TransformObject * transform;
	D2D_VECTOR_2F scdelta;
	float deltasX;
	D2D_VECTOR_2F delta;
	bool sc_check = NULL;
	
	D2D1_POINT_2F ch_scrollSpeed;
};

