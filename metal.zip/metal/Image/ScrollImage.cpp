#include "../framework.h"
#include "ScrollImage.h"
#include "../ImageEffect/Border.h"
#include "../Exe/ExeGame.h"

ScrollImage::ScrollImage(D2D1_POINT_2F scrollSpeed)
	: scrollSpeed(scrollSpeed)
{
	AddEffect(new Border());
}

ScrollImage::~ScrollImage()
{
}

void ScrollImage::Update()
{
	D2D1_SIZE_F renderTargetSize = D2D::GetRenderTarget()->GetSize();
	D2D1_POINT_2F targetOffset = static_cast<Border*>(imageEffect)->TargetOffset();
	scrollSpeed = GetSpeed();

	targetOffset.x += scrollSpeed.x * Time::Delta();
	targetOffset.y += scrollSpeed.y * Time::Delta();
	
	if (targetOffset.x > ImageSize().width)
		targetOffset.x -= ImageSize().width;
	if (targetOffset.x < -ImageSize().width)
		targetOffset.x += ImageSize().width;

	if (targetOffset.y > ImageSize().height)
		targetOffset.y -= ImageSize().height;
	if (targetOffset.y < -ImageSize().height)
		targetOffset.y += ImageSize().height;

	static_cast<Border*>(imageEffect)->TargetOffset(targetOffset);

	__super::Update();
}