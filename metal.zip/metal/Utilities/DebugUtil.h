#pragma once

#ifdef UNICODE
#define DebugPrint  DebugUtil::DebugPrintW
#else
#define DebugPrint  DebugUtil::DebugPrintA
#endif // !UNICODE

class DebugUtil
{
public:
	static void DebugPrintA(const char * format, ...);	// �������� ��� �Լ�
	static void DebugPrintW(const wchar_t * format, ...);

	static void AssertPrint(const char * format, LPSTR filePath, int LineNo);
	
};

	