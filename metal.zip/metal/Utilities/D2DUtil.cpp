#include "../framework.h"
#include "D2DUtil.h"

//D2DUtil

D2D1_VECTOR_2F & D2DUtil::NomalizeVector2F(D2D1_VECTOR_2F & vec)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	vec.x *= rate.x;
	vec.y *= rate.y;
	return vec;
}

D2D1_POINT_2F & D2DUtil::NomalizePoint2F(D2D1_POINT_2F & point)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	point.x *= rate.x;
	point.y *= rate.y;
	return point;
}

D2D1_POINT_2U & D2DUtil::NomalizePoint2U(D2D1_POINT_2U & point)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	point.x = static_cast<UINT32>(point.x * rate.x);
	point.y = static_cast<UINT32>(point.y * rate.y);
	return point;
}

D2D1_RECT_F& D2DUtil::NomalizeRectF(D2D1_RECT_F & rect)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	rect.left *= rate.x;
	rect.top *= rate.y;
	rect.right *= rate.x;
	rect.bottom *= rate.y;
	return rect;
}

D2D1_RECT_U & D2DUtil::NomalizeRectU(D2D1_RECT_U & rect)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	rect.left = static_cast<UINT32>(rect.left * rate.x);
	rect.top = static_cast<UINT32>(rect.top * rate.y);
	rect.right = static_cast<UINT32>(rect.right * rate.x);
	rect.bottom = static_cast<UINT32>(rect.bottom * rate.y);
	return rect;
}

D2D1_SIZE_F & D2DUtil::NomalizeSizeF(D2D1_SIZE_F & size)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	size.width *= rate.x;
	size.height *= rate.y;
	return size;
}

D2D1_SIZE_U & D2DUtil::NomalizeSizeU(D2D1_SIZE_U & size)
{
	D2D_VECTOR_2F rate = D2D::GetTargetRate();
	size.width = static_cast<UINT32>(size.width * rate.x);
	size.height = static_cast<UINT32>(size.height * rate.y);
	return size;
}


void D2DUtil::FixRect(D2D1_RECT_F& rect)
{
	FLOAT temp;
	if (rect.left > rect.right)
	{
		temp = rect.left;
		rect.left = rect.right;
		rect.right = temp;
	}

	if (rect.top > rect.bottom)
	{
		temp = rect.top;
		rect.top = rect.bottom;
		rect.bottom = temp;
	}
}

bool D2DUtil::IsSameMatrix3x2F(Matrix3x2F m1, Matrix3x2F m2)
{
	if (m1._11 == m2._11
		&& m1._12 == m2._12
		&& m1._21 == m2._21
		&& m1._22 == m2._22
		&& m1._31 == m2._31
		&& m1._32 == m2._32
		)
	{
		return true;
	}

	return false;
}
