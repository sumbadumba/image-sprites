#include "framework.h"
#include "Program.h"
#include "Exe/ExeGame.h"
#include"Exe/ExeBoundEdit.h"

Program::Program()
{
	D2DDesc desc;
	D2D::GetDesc(&desc);

	values = new ExecuteValues();

	renderTargetTransform = D2D1::Matrix3x2F::Identity();
	clearColor = D2D1::ColorF(D2D1::ColorF::LightSlateGray);
}

Program::~Program()
{
	for (Exe* exe : Exes)
		SAFE_DELETE(exe);

	SAFE_DELETE(values);
}

void Program::Initialize()
{
	values->TargetRate = D2D::GetTargetRate();
	Exes.push_back(new ExeGame(values));
	//Exes.push_back(new ExeBoundEdit(values));
}


void Program::Update()
{
	for (Exe* exe : Exes)
		exe->Update();
}

void Program::Render()
{
	D2D::BeginDraw();
	D2D::SetTransform(renderTargetTransform);
	D2D::Clear(clearColor);

	for (Exe* exe : Exes)
		exe->Render();

	HRESULT result = D2D::EndDraw();
	if (result == D2DERR_RECREATE_TARGET)
	{
		result = S_OK;
	}
	D2D::Flush();
}
